(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "./node_modules/@ionic/core/dist/esm-es5/framework-delegate-d1eb6504.js":
/*!******************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5/framework-delegate-d1eb6504.js ***!
  \******************************************************************************/
/*! exports provided: a, d */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return attachComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return detachComponent; });
const attachComponent = async (delegate, container, component, cssClasses, componentProps) => {
    if (delegate) {
        return delegate.attachViewToDom(container, component, componentProps, cssClasses);
    }
    if (typeof component !== 'string' && !(component instanceof HTMLElement)) {
        throw new Error('framework delegate is missing');
    }
    const el = (typeof component === 'string')
        ? container.ownerDocument && container.ownerDocument.createElement(component)
        : component;
    if (cssClasses) {
        cssClasses.forEach(c => el.classList.add(c));
    }
    if (componentProps) {
        Object.assign(el, componentProps);
    }
    container.appendChild(el);
    if (el.componentOnReady) {
        await el.componentOnReady();
    }
    return el;
};
const detachComponent = (delegate, element) => {
    if (element) {
        if (delegate) {
            const container = element.parentElement;
            return delegate.removeViewFromDom(container, element);
        }
        element.remove();
    }
    return Promise.resolve();
};




/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm-es5/haptic-ccbda579.js":
/*!******************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5/haptic-ccbda579.js ***!
  \******************************************************************/
/*! exports provided: a, b, c, h */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return hapticSelectionStart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return hapticSelectionChanged; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return hapticSelectionEnd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return hapticSelection; });
/**
 * Check to see if the Haptic Plugin is available
 * @return Returns `true` or false if the plugin is available
 */
/**
 * Trigger a selection changed haptic event. Good for one-time events
 * (not for gestures)
 */
const hapticSelection = () => {
    const engine = window.TapticEngine;
    if (engine) {
        engine.selection();
    }
};
/**
 * Tell the haptic engine that a gesture for a selection change is starting.
 */
const hapticSelectionStart = () => {
    const engine = window.TapticEngine;
    if (engine) {
        engine.gestureSelectionStart();
    }
};
/**
 * Tell the haptic engine that a selection changed during a gesture.
 */
const hapticSelectionChanged = () => {
    const engine = window.TapticEngine;
    if (engine) {
        engine.gestureSelectionChanged();
    }
};
/**
 * Tell the haptic engine we are done with a gesture. This needs to be
 * called lest resources are not properly recycled.
 */
const hapticSelectionEnd = () => {
    const engine = window.TapticEngine;
    if (engine) {
        engine.gestureSelectionEnd();
    }
};




/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm-es5/index-729ec402.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5/index-729ec402.js ***!
  \*****************************************************************/
/*! exports provided: s */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "s", function() { return sanitizeDOMString; });
/**
 * Does a simple sanitization of all elements
 * in an untrusted string
 */
const sanitizeDOMString = (untrustedString) => {
    try {
        if (typeof untrustedString !== 'string' || untrustedString === '') {
            return untrustedString;
        }
        /**
         * Create a document fragment
         * separate from the main DOM,
         * create a div to do our work in
         */
        const documentFragment = document.createDocumentFragment();
        const workingDiv = document.createElement('div');
        documentFragment.appendChild(workingDiv);
        workingDiv.innerHTML = untrustedString;
        /**
         * Remove any elements
         * that are blocked
         */
        blockedTags.forEach(blockedTag => {
            const getElementsToRemove = documentFragment.querySelectorAll(blockedTag);
            for (let elementIndex = getElementsToRemove.length - 1; elementIndex >= 0; elementIndex--) {
                const element = getElementsToRemove[elementIndex];
                if (element.parentNode) {
                    element.parentNode.removeChild(element);
                }
                else {
                    documentFragment.removeChild(element);
                }
                /**
                 * We still need to sanitize
                 * the children of this element
                 * as they are left behind
                 */
                const childElements = getElementChildren(element);
                /* tslint:disable-next-line */
                for (let childIndex = 0; childIndex < childElements.length; childIndex++) {
                    sanitizeElement(childElements[childIndex]);
                }
            }
        });
        /**
         * Go through remaining elements and remove
         * non-allowed attribs
         */
        // IE does not support .children on document fragments, only .childNodes
        const dfChildren = getElementChildren(documentFragment);
        /* tslint:disable-next-line */
        for (let childIndex = 0; childIndex < dfChildren.length; childIndex++) {
            sanitizeElement(dfChildren[childIndex]);
        }
        // Append document fragment to div
        const fragmentDiv = document.createElement('div');
        fragmentDiv.appendChild(documentFragment);
        // First child is always the div we did our work in
        const getInnerDiv = fragmentDiv.querySelector('div');
        return (getInnerDiv !== null) ? getInnerDiv.innerHTML : fragmentDiv.innerHTML;
    }
    catch (err) {
        console.error(err);
        return '';
    }
};
/**
 * Clean up current element based on allowed attributes
 * and then recursively dig down into any child elements to
 * clean those up as well
 */
const sanitizeElement = (element) => {
    // IE uses childNodes, so ignore nodes that are not elements
    if (element.nodeType && element.nodeType !== 1) {
        return;
    }
    for (let i = element.attributes.length - 1; i >= 0; i--) {
        const attribute = element.attributes.item(i);
        const attributeName = attribute.name;
        // remove non-allowed attribs
        if (!allowedAttributes.includes(attributeName.toLowerCase())) {
            element.removeAttribute(attributeName);
            continue;
        }
        // clean up any allowed attribs
        // that attempt to do any JS funny-business
        const attributeValue = attribute.value;
        /* tslint:disable-next-line */
        if (attributeValue != null && attributeValue.toLowerCase().includes('javascript:')) {
            element.removeAttribute(attributeName);
        }
    }
    /**
     * Sanitize any nested children
     */
    const childElements = getElementChildren(element);
    /* tslint:disable-next-line */
    for (let i = 0; i < childElements.length; i++) {
        sanitizeElement(childElements[i]);
    }
};
/**
 * IE doesn't always support .children
 * so we revert to .childNodes instead
 */
const getElementChildren = (el) => {
    return (el.children != null) ? el.children : el.childNodes;
};
const allowedAttributes = ['class', 'id', 'href', 'src', 'name', 'slot'];
const blockedTags = ['script', 'style', 'iframe', 'meta', 'link', 'object', 'embed'];




/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm-es5/spinner-configs-c78e170e.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5/spinner-configs-c78e170e.js ***!
  \***************************************************************************/
/*! exports provided: S */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "S", function() { return SPINNERS; });
const spinners = {
    'bubbles': {
        dur: 1000,
        circles: 9,
        fn: (dur, index, total) => {
            const animationDelay = `${(dur * index / total) - dur}ms`;
            const angle = 2 * Math.PI * index / total;
            return {
                r: 5,
                style: {
                    'top': `${9 * Math.sin(angle)}px`,
                    'left': `${9 * Math.cos(angle)}px`,
                    'animation-delay': animationDelay,
                }
            };
        }
    },
    'circles': {
        dur: 1000,
        circles: 8,
        fn: (dur, index, total) => {
            const step = index / total;
            const animationDelay = `${(dur * step) - dur}ms`;
            const angle = 2 * Math.PI * step;
            return {
                r: 5,
                style: {
                    'top': `${9 * Math.sin(angle)}px`,
                    'left': `${9 * Math.cos(angle)}px`,
                    'animation-delay': animationDelay,
                }
            };
        }
    },
    'circular': {
        dur: 1400,
        elmDuration: true,
        circles: 1,
        fn: () => {
            return {
                r: 20,
                cx: 48,
                cy: 48,
                fill: 'none',
                viewBox: '24 24 48 48',
                transform: 'translate(0,0)',
                style: {}
            };
        }
    },
    'crescent': {
        dur: 750,
        circles: 1,
        fn: () => {
            return {
                r: 26,
                style: {}
            };
        }
    },
    'dots': {
        dur: 750,
        circles: 3,
        fn: (_, index) => {
            const animationDelay = -(110 * index) + 'ms';
            return {
                r: 6,
                style: {
                    'left': `${9 - (9 * index)}px`,
                    'animation-delay': animationDelay,
                }
            };
        }
    },
    'lines': {
        dur: 1000,
        lines: 12,
        fn: (dur, index, total) => {
            const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
            const animationDelay = `${(dur * index / total) - dur}ms`;
            return {
                y1: 17,
                y2: 29,
                style: {
                    'transform': transform,
                    'animation-delay': animationDelay,
                }
            };
        }
    },
    'lines-small': {
        dur: 1000,
        lines: 12,
        fn: (dur, index, total) => {
            const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
            const animationDelay = `${(dur * index / total) - dur}ms`;
            return {
                y1: 12,
                y2: 20,
                style: {
                    'transform': transform,
                    'animation-delay': animationDelay,
                }
            };
        }
    }
};
const SPINNERS = spinners;




/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm-es5/theme-c2dc54d9.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5/theme-c2dc54d9.js ***!
  \*****************************************************************/
/*! exports provided: c, g, h, o */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return createColorClasses; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return getClassMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return hostContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return openURL; });
const hostContext = (selector, el) => {
    return el.closest(selector) !== null;
};
/**
 * Create the mode and color classes for the component based on the classes passed in
 */
const createColorClasses = (color) => {
    return (typeof color === 'string' && color.length > 0) ? {
        'ion-color': true,
        [`ion-color-${color}`]: true
    } : undefined;
};
const getClassList = (classes) => {
    if (classes !== undefined) {
        const array = Array.isArray(classes) ? classes : classes.split(' ');
        return array
            .filter(c => c != null)
            .map(c => c.trim())
            .filter(c => c !== '');
    }
    return [];
};
const getClassMap = (classes) => {
    const map = {};
    getClassList(classes).forEach(c => map[c] = true);
    return map;
};
const SCHEME = /^[a-z][a-z0-9+\-.]*:/;
const openURL = async (url, ev, direction) => {
    if (url != null && url[0] !== '#' && !SCHEME.test(url)) {
        const router = document.querySelector('ion-router');
        if (router) {
            if (ev != null) {
                ev.preventDefault();
            }
            return router.push(url, direction);
        }
    }
    return false;
};




/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/masinfo/masinfo.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/masinfo/masinfo.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Modal</ion-title>\n    <ion-button (click)=\"Cerrar()\" size=\"small\" slot=\"end\">\n      <ion-icon name=\"close-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n<div class=\"texto1\" >\n  ECU 19 es una organización sin fines de lucro que recoge  y proporciona  información en tiempo real\n  sobre la propagación de COVID-19 en su comunidad local y en todo el país.\n  Somos un grupo de científicos, ingenieros y médicos y hemos creado una\n  herramienta para proveer información sobre COVID -19. Esta app ha sido diseñada para ayudar a\n  incrementar la concientización y producir una meseta en la curva de crecimiento y expansión de la\n  infección por COVID 19, informando a los ecuatorianos y los sistemas de salud con temas relevantes. Por\n  favor revisar las políticas de privacidad y términos de servicio.\n  Por favor díganos cómo se siente.\n  Sus respuestas se recopilan y se pondrán a disposición del público, incluso a través de nuestro sitio web\n  para ayudar a los proveedores de atención médica, investigadores y otras personas a medir la\n  propagación de COVID-19 e informar los esfuerzos que ayudan a mantenerse a usted, a su familia y a su\n  comunidad saludables. Utilizaremos nuestros esfuerzos de buena fe para garantizar que sus respuestas\n  se compartan de manera sintetizada, como en el mapa de calor que puede ver siguiendo el enlace en\n  nuestro panel de navegación.\n  El siguiente cuestionario está diseñado para ayudar a recopilar información sobre factores de riesgo\n  para la infección por COVID-19. Las preguntas se basan en la mejor orientación disponible de las\n  agencias de salud pública y otras partes interesadas y se actualizarán periódicamente.\n  Esta encuesta no pretende facilitar ningún tipo de diagnóstico o autoevaluación para COVID-19. Si\n  sospecha que puede tener COVID-19, busque atención médica.\n  Revise nuestros Términos de servicio y nuestra Política de privacidad detenidamente y si no está de\n  acuerdo con nuestros Términos de servicio o no se siente cómodo con nuestra recopilación, uso y\n  divulgación de la información que proporciona, no complete esta Encuesta (aunque le agradeceríamos si\n  puede enviarnos sus comentarios a flattenofficial@gmail.com sobre cómo podemos abordar sus\n  inquietudes)\n\n</div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/coneccion.service.ts":
/*!**************************************!*\
  !*** ./src/app/coneccion.service.ts ***!
  \**************************************/
/*! exports provided: ConeccionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConeccionService", function() { return ConeccionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var ConeccionService = /** @class */ (function () {
    function ConeccionService(http) {
        this.http = http;
        //public   URL = 'https://datos.ingenio-ti.com/';
        // public   URL = 'http://localhost/cerco/';
        this.URL = 'http://covid.uta.edu.ec/';
    }
    ConeccionService.prototype.getProvincia = function () {
        return this.http.get('assets/dpa/provincias.json');
    };
    ConeccionService.prototype.getCanton = function () {
        return this.http.get('assets/dpa/canton.json');
    };
    ConeccionService.prototype.getParroquia = function () {
        return this.http.get('assets/dpa/parroquia.json');
    };
    ConeccionService.prototype.getgeojson = function () {
        return this.http.get('assets/dpa/puntos.geojson');
    };
    ConeccionService.prototype.guardar = function (sp1, sp2, sp3, vp1, vp2, vp3, vp4, vp5, vp6, vp7, provincia, canton, parroquia, dispositivo, ci, lat, lon, ot1, ot2, facultad, carrera, txtcedula, lugartrabajo) {
        var urlServer = this.URL + 'registro.php?op=insert';
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]();
        //body = body.set('op', 'login');
        body = body.set('sp1', sp1);
        body = body.set('sp2', sp2);
        body = body.set('sp3', sp3);
        body = body.set('vp1', vp1);
        body = body.set('vp2', vp2);
        body = body.set('vp3', vp3);
        body = body.set('vp4', vp4);
        body = body.set('vp5', vp5);
        body = body.set('vp6', vp6);
        body = body.set('vp7', vp7);
        body = body.set('vp7', vp7);
        body = body.set('ot1', ot1);
        body = body.set('ot2', ot2);
        body = body.set('facultad', facultad);
        body = body.set('carrera', carrera);
        body = body.set('carrera', carrera);
        body = body.set('provincia', provincia);
        body = body.set('canton', canton);
        body = body.set('parroquia', parroquia);
        body = body.set('dispositivo', dispositivo);
        body = body.set('ci', ci);
        body = body.set('lon', lon);
        body = body.set('lat', lat);
        body = body.set('txtcedula', txtcedula);
        body = body.set('lugartrabajo', lugartrabajo);
        return this.http.post(urlServer, body, { responseType: 'json' });
    };
    ConeccionService.prototype.getParroquiasGeoJson = function (indicador, siono) {
        var urlServer = this.URL + 'registro.php?op=select-parroquias';
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]();
        body = body.set('indicador', indicador);
        body = body.set('siono', siono);
        return this.http.post(urlServer, body, { responseType: 'json' });
    };
    ConeccionService.prototype.getPuntos = function () {
        var urlServer = this.URL + 'registro.php?op=select-puntos';
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]();
        //body = body.set('indicador', indicador);
        //body = body.set('siono', siono);
        return this.http.post(urlServer, body, { responseType: 'json' });
    };
    ConeccionService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    ConeccionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ConeccionService);
    return ConeccionService;
}());



/***/ }),

/***/ "./src/app/masinfo/masinfo-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/masinfo/masinfo-routing.module.ts ***!
  \***************************************************/
/*! exports provided: MasinfoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MasinfoPageRoutingModule", function() { return MasinfoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _masinfo_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./masinfo.page */ "./src/app/masinfo/masinfo.page.ts");




var routes = [
    {
        path: '',
        component: _masinfo_page__WEBPACK_IMPORTED_MODULE_3__["MasinfoPage"]
    }
];
var MasinfoPageRoutingModule = /** @class */ (function () {
    function MasinfoPageRoutingModule() {
    }
    MasinfoPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], MasinfoPageRoutingModule);
    return MasinfoPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/masinfo/masinfo.module.ts":
/*!*******************************************!*\
  !*** ./src/app/masinfo/masinfo.module.ts ***!
  \*******************************************/
/*! exports provided: MasinfoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MasinfoPageModule", function() { return MasinfoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm5/ionic-angular.js");
/* harmony import */ var _masinfo_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./masinfo-routing.module */ "./src/app/masinfo/masinfo-routing.module.ts");
/* harmony import */ var _masinfo_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./masinfo.page */ "./src/app/masinfo/masinfo.page.ts");







var MasinfoPageModule = /** @class */ (function () {
    function MasinfoPageModule() {
    }
    MasinfoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _masinfo_routing_module__WEBPACK_IMPORTED_MODULE_5__["MasinfoPageRoutingModule"]
            ],
            declarations: [_masinfo_page__WEBPACK_IMPORTED_MODULE_6__["MasinfoPage"]]
        })
    ], MasinfoPageModule);
    return MasinfoPageModule;
}());



/***/ }),

/***/ "./src/app/masinfo/masinfo.page.scss":
/*!*******************************************!*\
  !*** ./src/app/masinfo/masinfo.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".texto1 {\n  text-align: left;\n  font: Regular 19px/25px Arial;\n  font-family: Arial;\n  font-size: 19px;\n  letter-spacing: 0;\n  opacity: 1;\n  padding-left: 30px;\n  padding-right: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFzaW5mby9EOlxcT1JMQU5ET1xcVFJBQkFKT1NcXGNvdmlkMTlcXGNlcmNvL3NyY1xcYXBwXFxtYXNpbmZvXFxtYXNpbmZvLnBhZ2Uuc2NzcyIsInNyYy9hcHAvbWFzaW5mby9tYXNpbmZvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUVBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9tYXNpbmZvL21hc2luZm8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRleHRvMSB7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgZm9udDogUmVndWxhciAxOXB4LzI1cHggQXJpYWw7XHJcbiAgICBmb250LWZhbWlseTogQXJpYWw7XHJcbiAgICBmb250LXNpemU6IDE5cHg7XHJcbiAgICBsZXR0ZXItc3BhY2luZzogMDtcclxuICBcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAzMHB4O1xyXG4gIH0iLCIudGV4dG8xIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udDogUmVndWxhciAxOXB4LzI1cHggQXJpYWw7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbDtcbiAgZm9udC1zaXplOiAxOXB4O1xuICBsZXR0ZXItc3BhY2luZzogMDtcbiAgb3BhY2l0eTogMTtcbiAgcGFkZGluZy1sZWZ0OiAzMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAzMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/masinfo/masinfo.page.ts":
/*!*****************************************!*\
  !*** ./src/app/masinfo/masinfo.page.ts ***!
  \*****************************************/
/*! exports provided: MasinfoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MasinfoPage", function() { return MasinfoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm5/ionic-angular.js");



var MasinfoPage = /** @class */ (function () {
    function MasinfoPage(modalCtrl) {
        this.modalCtrl = modalCtrl;
    }
    MasinfoPage.prototype.ngOnInit = function () {
    };
    MasinfoPage.prototype.Cerrar = function () {
        this.modalCtrl.dismiss({
            dismissed: true
        });
    };
    MasinfoPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    MasinfoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-masinfo',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./masinfo.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/masinfo/masinfo.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./masinfo.page.scss */ "./src/app/masinfo/masinfo.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], MasinfoPage);
    return MasinfoPage;
}());



/***/ })

}]);
//# sourceMappingURL=common.js.map