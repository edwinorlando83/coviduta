(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["formulario-formulario-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/formulario/formulario.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/formulario/formulario.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <img   style=\"align-self: center; width: 130px;\" src=\"assets/COVIDUTA.svg\"/>\n    <ion-icon (click)=\"reporte()\" name=\"print-outline\" slot=\"end\" > </ion-icon>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    \n  \n\n    <ion-row>\n      <ion-col     offset-xl=\"4\"\n      size-xl=\"4\"\n\n      offset-sm=\"2\"\n      size-sm=\"8\"\n\n      offset-md=\"3\"\n      size-md=\"6\"\n\n   \n      size-xs=\"12\" >\n       \n <table>\n   <tr>\n     <td align=\"center\">\n  <img style=\"width: 350px;\" src=\"assets/ayuda.jpg\" />\n     </td>\n   </tr>\n   <tr>\n    <td style=\"background-color: #F4F4F4; padding-top: 10px;\">\n      <div class=\"texto1\"> \n      Tus respuestas serán <b> compartidas anónimamente  </b> para ayudar a gestionar investigación, ayuda y otras causas sobre el esparcimiento del COVID-19.\n    <p>  </p>\n    </div>\n\n    </td>\n  </tr>\n\n  <tr>\n    <td style=\"  padding-top: 20px;\">\n      <div class=\"tema1\">\n        Marque la pregunta si su respuesta es <span style=\"color:#BB222E\">SI </span>\n        <p></p>\n      </div>\n\n    </td>\n  </tr>\n\n  <tr>\n    <td style=\"background-color: #F4F4F4; \">\n      \n      <table style=\" margin-left: 20px;  width: 92%;\">\n        <tr>\n          <td width=\"75%\"  class=\"titulotabla\">\n            Síntomas\n          </td>\n          <td align=\"center\" class=\"titulotabla\">\n          \n          </td>\n        </tr>\n        <tr  class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Tiene fiebre, escalofríos o temblores?\n          </td>\n          <td  align=\"center\"  >\n            <ion-checkbox   [(ngModel)]=\"sp1\" mode=\"ios\" color=\"danger\"> \n\n            </ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Tiene una tos nueva o que empeora?\n          </td>\n          <td align=\"center\">\n            <ion-checkbox\n              [(ngModel)]=\"sp2\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Experimenta dificultad para respirar?\n          </td>\n          <td align=\"center\" >\n            <ion-checkbox\n              [(ngModel)]=\"sp3\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n      </table>\n\n\n      <table style=\" margin-left: 20px;  width: 92%;\">\n        <tr>\n          <td width=\"75%\" class=\"titulotabla\">\n            Vulnerabilidad\n          </td>\n        \n        </tr>\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Tiene 60 años de edad o más?\n          </td>\n          <td align=\"center\" >\n            <ion-checkbox\n              [(ngModel)]=\"vp1\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Tiene alguna de las siguientes condiciones médicas: diabetes,\n            enfermedad cardíaca, cáncer activo, antecedentes de accidente\n            cerebrovascular, asma, EPOC, diálisis o están inmunocomprometidos?\n          </td>\n          <td align=\"center\">\n            <ion-checkbox\n              [(ngModel)]=\"vp2\"\n              mode=\"ios\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Ha viajado fuera de Ecuador en los últimos 14 días?\n          </td>\n          <td align=\"center\">\n            <ion-checkbox\n              [(ngModel)]=\"vp3\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Ha tenido contacto cercano con alguien que está tosiendo, tiene\n            fiebre, está enfermo o ha sido diagnosticado con COVID-19?\n          </td>\n          <td align=\"center\">\n            <ion-checkbox\n              [(ngModel)]=\"vp4\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Su situación económica es delicada?\n          </td>\n          <td align=\"center\">\n            <ion-checkbox\n              [(ngModel)]=\"vp5\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Tiene familiares recuperados del virus covit-19?\n          </td>\n          <td align=\"center\">\n            <ion-checkbox\n              [(ngModel)]=\"vp6\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Tiene familiares que han fallecido por el virus Covit-19?\n          </td>\n          <td align=\"center\">\n            <ion-checkbox\n              [(ngModel)]=\"vp7\"\n              mode=\"ios\"\n              color=\"danger\"\n            ></ion-checkbox>\n          </td>\n        </tr>\n      </table>\n\n      <table style=\" margin-left: 20px;  width: 92%;\">\n        <tr>\n          <td width=\"40%\" class=\"titulotabla\" colspan=\"2\">\n            Locación o Ubicación\n          </td>\n        </tr>\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            <b class=\"obligado\"> *</b>    Provincia\n          </td>\n          <td>\n\n           \n\n            <ion-select mode=\"ios\"\n              [(ngModel)]=\"provincia_selecionado\"\n              (ionChange)=\"getcantones( )\"\n              placeholder=\"Seleccione\"\n              interface=\"popover\"\n            >\n         \n              <ion-select-option   \n              *ngFor=\"let provincia of provincias\"\n              value=\"{{provincia.dpa_provin}}\"\n            >\n              {{provincia.dpa_despro}}\n            </ion-select-option>\n           \n          \n            </ion-select>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            <b class=\"obligado\"> *</b>   Cantón\n          </td>\n          <td>\n            <ion-select\n              *ngIf=\"provincia_selecionado\"\n              [(ngModel)]=\"canton_selecionado\"\n              (ionChange)=\"getparroquias( )\"\n              placeholder=\"Seleccione\"\n              interface=\"popover\"\n              mode=\"ios\"\n            >\n              <ion-select-option\n                *ngFor=\"let canton of cantones\"\n                value=\"{{canton.dpa_canton}}\"\n              >\n                {{canton.dpa_descan}}\n              </ion-select-option>\n            </ion-select>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            <b class=\"obligado\"> *</b>  Parroquia\n          </td>\n          <td>\n            <ion-select\n              *ngIf=\"canton_selecionado\"\n              (ionChange)=\"changeParroquias( )\"\n              [(ngModel)]=\"parroquia_selecionado\"\n              placeholder=\"Seleccione\"\n              interface=\"popover\"\n               mode=\"ios\"\n            >\n              <ion-select-option\n                *ngFor=\"let parr of parroquias \"\n                value=\"{{parr.dpa_parroq}}\"\n              >\n                {{parr.dpa_despar}}\n              </ion-select-option>\n            </ion-select>\n          </td>\n        </tr>\n      </table>\n\n       \n\n\n      <table style=\" margin-left: 20px;  width: 92%;\">\n        <tr>\n          <td width=\"40%\" class=\"titulotabla\" colspan=\"2\">\n            Diagnóstico \n          </td>\n        </tr>\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Se ha hecho una prueba rapida de Covid19?\n          </td>\n          <td  align=\"center\">\n            <ion-checkbox\n            [(ngModel)]=\"ot1\"\n            mode=\"ios\"\n            color=\"danger\"\n          ></ion-checkbox>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n            ¿Ha tenido un PCR +?\n          </td>\n          <td align=\"center\">\n            <ion-checkbox\n            [(ngModel)]=\"ot2\"\n            mode=\"ios\"\n            color=\"danger\"\n          ></ion-checkbox>\n          </td>\n        </tr>\n\n   \n      </table>\n\n      <table style=\" margin-left: 20px;  width: 92%;\">\n        <tr>\n          <td width=\"40%\" class=\"titulotabla\" colspan=\"2\">\n            Otros\n          </td>\n        </tr>\n        <tr class=\"fila\">\n          <td class=\"textoPregunta\">\n             Facultad \n          </td>\n          <td  >\n            <ion-item> \n            <ion-input  [(ngModel)]=\"facultad\"> </ion-input>\n          </ion-item>\n          </td>\n        </tr>\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta \">\n             Carrera\n          </td>\n          <td  >\n            <ion-item> \n              <ion-input  [(ngModel)]=\"carrera\" > </ion-input>\n            </ion-item>\n          </td>\n        </tr>\n\n\n        <tr class=\"fila\">\n          <td class=\"textoPregunta \">\n            <b class=\"obligado\"> *</b>  Cédula\n          </td>\n          <td  >\n            <ion-item> \n              <ion-input  [(ngModel)]=\"txtCedula\" > </ion-input>\n            </ion-item>\n          </td>\n        </tr>\n        <tr class=\"fila\">\n          <td class=\"textoPregunta \">\n              Lugar de Trabajo\n          </td>\n          <td  >\n            <ion-item> \n              <ion-input  [(ngModel)]=\"txtLugartrabajo\" > </ion-input>\n            </ion-item>\n          </td>\n        </tr>\n   \n      </table>\n\n <p></p>\n\n\n\n    </td>\n  </tr>\n\n </table>\n\n       \n\n\n      </ion-col>\n    </ion-row>\n \n \n    <ion-row>\n      <ion-col offset-xl=\"4\" size-xl=\"4\" offset-sm=\"3\" size-sm=\"6\" size-xs=\"12\">\n        <div *ngIf=\"guardar\" class=\"advertencia\">\n          Al enviar la información, certifica que usted  es mayor de edad y acepta los Términos de uso y la Política de privacidad. En caso de no estar deacuerdo, por favor no envíe esta información \n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col \n      offset-xl=\"4\"\n      size-xl=\"4\"\n\n      offset-sm=\"2\"\n      size-sm=\"8\"\n\n      offset-md=\"3\"\n      size-md=\"6\"\n\n      offset-xs=\"1\"\n      size-xs=\"10\"\n\n      >\n        <ion-button style=\"margin-right: 10px;margin-left: 10px;\" expand=\"block\"\n          [disabled]=\"!guardar\"\n          (click)=\"guardarDatos()\"          \n          \n          color=\"danger\"\n         \n        >\n          <div class=\"textoBoton\">Enviar</div>\n        </ion-button>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/formulario/formulario-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/formulario/formulario-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: FormularioPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormularioPageRoutingModule", function() { return FormularioPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _formulario_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./formulario.page */ "./src/app/formulario/formulario.page.ts");




var routes = [
    {
        path: '',
        component: _formulario_page__WEBPACK_IMPORTED_MODULE_3__["FormularioPage"]
    }
];
var FormularioPageRoutingModule = /** @class */ (function () {
    function FormularioPageRoutingModule() {
    }
    FormularioPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], FormularioPageRoutingModule);
    return FormularioPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/formulario/formulario.module.ts":
/*!*************************************************!*\
  !*** ./src/app/formulario/formulario.module.ts ***!
  \*************************************************/
/*! exports provided: FormularioPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormularioPageModule", function() { return FormularioPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm5/ionic-angular.js");
/* harmony import */ var _formulario_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./formulario-routing.module */ "./src/app/formulario/formulario-routing.module.ts");
/* harmony import */ var _formulario_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./formulario.page */ "./src/app/formulario/formulario.page.ts");
/* harmony import */ var _masinfo_masinfo_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../masinfo/masinfo.module */ "./src/app/masinfo/masinfo.module.ts");








var FormularioPageModule = /** @class */ (function () {
    function FormularioPageModule() {
    }
    FormularioPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _formulario_routing_module__WEBPACK_IMPORTED_MODULE_5__["FormularioPageRoutingModule"],
                _masinfo_masinfo_module__WEBPACK_IMPORTED_MODULE_7__["MasinfoPageModule"]
            ],
            declarations: [_formulario_page__WEBPACK_IMPORTED_MODULE_6__["FormularioPage"]]
        })
    ], FormularioPageModule);
    return FormularioPageModule;
}());



/***/ }),

/***/ "./src/app/formulario/formulario.page.scss":
/*!*************************************************!*\
  !*** ./src/app/formulario/formulario.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".texto1 {\n  text-align: left;\n  font-family: Helvetica Neue LT Pro;\n  font-size: 16px;\n  letter-spacing: 0;\n  opacity: 1;\n  padding-left: 30px;\n  padding-right: 30px;\n}\n\n.tema1 {\n  font-weight: bold;\n  opacity: 1;\n  text-align: center;\n  font-family: Helvetica Neue LT Pro;\n  letter-spacing: 0;\n  color: #333333;\n  opacity: 1;\n  padding-left: 20px;\n}\n\n.titulotabla {\n  text-align: left;\n  font-family: Helvetica Neue LT Pro;\n  font-weight: bold;\n  font-size: 16px;\n  letter-spacing: 0;\n  color: #272727;\n  opacity: 1;\n  padding-bottom: 15px;\n  padding-top: 15px;\n  padding-left: 20px;\n}\n\n.textoPregunta {\n  text-align: left;\n  font-family: Helvetica Neue LT Pro;\n  font-size: 16px;\n  letter-spacing: 0;\n  color: #272727;\n  opacity: 1;\n  padding-top: 20px;\n  padding-bottom: 20px;\n  padding-left: 30px;\n  padding-right: 10px;\n}\n\n.fila {\n  border-color: #00000029;\n  border-width: 1px;\n  border-style: solid;\n  background-color: #ffffff;\n}\n\n.textoBoton {\n  font: Medium 25px/33px Roboto;\n  font-family: Roboto;\n  letter-spacing: 0;\n  color: #ffffff;\n  opacity: 1;\n  text-transform: none;\n}\n\n.advertencia {\n  text-align: left;\n  font: Regular 12px/16px Roboto;\n  font-family: Roboto;\n  font-size: 12px;\n  letter-spacing: 0;\n  color: #f9545b;\n  opacity: 1;\n  padding-top: 20px;\n  padding-bottom: 20px;\n  padding-left: 30px;\n  padding-right: 10px;\n}\n\n.textocedula {\n  font-family: Roboto;\n  font-size: 11px;\n}\n\nion-button {\n  --border-radius:9px;\n}\n\n.obligado {\n  color: #BB222E;\n}\n\n.alert-checkbox-group::-webkit-scrollbar {\n  width: 1em;\n  display: block !important;\n}\n\n.alert-checkbox-group::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);\n}\n\n.alert-checkbox-group::-webkit-scrollbar-thumb {\n  background-color: darkgrey;\n  outline: 1px solid slategrey;\n}\n\n.action-sheet-group {\n  flex-shrink: 2;\n  overscroll-behavior-y: contain;\n  overflow-y: scroll;\n  -webkit-overflow-scrolling: touch;\n  pointer-events: all;\n  background: var(--background);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9ybXVsYXJpby9EOlxcT1JMQU5ET1xcVFJBQkFKT1NcXGNvdmlkMTlcXGNlcmNvL3NyY1xcYXBwXFxmb3JtdWxhcmlvXFxmb3JtdWxhcmlvLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZm9ybXVsYXJpby9mb3JtdWxhcmlvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFFQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0RGOztBRElBO0VBQ0MsaUJBQUE7RUFFQyxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQ0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtBQ0ZGOztBREtBO0VBQ0UsZ0JBQUE7RUFFQSxrQ0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNIRjs7QURLQTtFQUNFLGdCQUFBO0VBRUEsa0NBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDSEY7O0FETUE7RUFDRSx1QkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQ0hGOztBRE9BO0VBQ0UsNkJBQUE7RUFDQSxtQkFBQTtFQUVBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7RUFDQSxvQkFBQTtBQ0xGOztBRFFBO0VBQ0UsZ0JBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0xGOztBRFFBO0VBQ0UsbUJBQUE7RUFDQyxlQUFBO0FDTEg7O0FET0E7RUFDRSxtQkFBQTtBQ0pGOztBRE9BO0VBQ0EsY0FBQTtBQ0pBOztBRE9BO0VBQ0UsVUFBQTtFQUNBLHlCQUFBO0FDSkY7O0FET0E7RUFDRSxvREFBQTtBQ0pGOztBRE9BO0VBQ0UsMEJBQUE7RUFDQSw0QkFBQTtBQ0pGOztBRE9BO0VBQ0UsY0FBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQ0FBQTtFQUNBLG1CQUFBO0VBRUEsNkJBQUE7QUNMRiIsImZpbGUiOiJzcmMvYXBwL2Zvcm11bGFyaW8vZm9ybXVsYXJpby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgXHJcbi50ZXh0bzEge1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgZm9udC1mYW1pbHk6IEhlbHZldGljYSBOZXVlIExUIFBybztcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGV0dGVyLXNwYWNpbmc6IDA7XHJcblxyXG4gIG9wYWNpdHk6IDE7XHJcbiAgcGFkZGluZy1sZWZ0OiAzMHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDMwcHg7XHJcbiBcclxufVxyXG4udGVtYTEge1xyXG4gZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgXHJcbiAgb3BhY2l0eTogMTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZm9udC1mYW1pbHk6IEhlbHZldGljYSBOZXVlIExUIFBybztcclxuICBsZXR0ZXItc3BhY2luZzogMDtcclxuICBjb2xvcjogIzMzMzMzMztcclxuICBvcGFjaXR5OiAxO1xyXG4gIHBhZGRpbmctbGVmdDogMjBweDtcclxuIFxyXG59XHJcbi50aXR1bG90YWJsYSB7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgXHJcbiAgZm9udC1mYW1pbHk6IEhlbHZldGljYSBOZXVlIExUIFBybztcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGV0dGVyLXNwYWNpbmc6IDA7XHJcbiAgY29sb3I6ICMyNzI3Mjc7XHJcbiAgb3BhY2l0eTogMTtcclxuICBwYWRkaW5nLWJvdHRvbTogMTVweDtcclxuICBwYWRkaW5nLXRvcDogMTVweDtcclxuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbn1cclxuLnRleHRvUHJlZ3VudGEge1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiBcclxuICBmb250LWZhbWlseTogSGVsdmV0aWNhIE5ldWUgTFQgUHJvO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBsZXR0ZXItc3BhY2luZzogMDtcclxuICBjb2xvcjogIzI3MjcyNztcclxuICBvcGFjaXR5OiAxO1xyXG4gIHBhZGRpbmctdG9wOiAyMHB4O1xyXG4gIHBhZGRpbmctYm90dG9tOiAyMHB4O1xyXG4gIHBhZGRpbmctbGVmdDogMzBweDtcclxuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xyXG59XHJcblxyXG4uZmlsYSB7XHJcbiAgYm9yZGVyLWNvbG9yOiAjMDAwMDAwMjk7XHJcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XHJcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gXHJcbn1cclxuXHJcbi50ZXh0b0JvdG9uIHtcclxuICBmb250OiBNZWRpdW0gMjVweC8zM3B4IFJvYm90bztcclxuICBmb250LWZhbWlseTogUm9ib3RvO1xyXG5cclxuICBsZXR0ZXItc3BhY2luZzogMDtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxuICBvcGFjaXR5OiAxO1xyXG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xyXG59XHJcblxyXG4uYWR2ZXJ0ZW5jaWEge1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgZm9udDogUmVndWxhciAxMnB4LzE2cHggUm9ib3RvO1xyXG4gIGZvbnQtZmFtaWx5OiBSb2JvdG87XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIGxldHRlci1zcGFjaW5nOiAwO1xyXG4gIGNvbG9yOiAjZjk1NDViO1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgcGFkZGluZy10b3A6IDIwcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDIwcHg7XHJcbiAgcGFkZGluZy1sZWZ0OiAzMHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbn1cclxuXHJcbi50ZXh0b2NlZHVsYXtcclxuICBmb250LWZhbWlseTogUm9ib3RvO1xyXG4gICBmb250LXNpemU6IDExcHg7XHJcbn1cclxuaW9uLWJ1dHRvbntcclxuICAtLWJvcmRlci1yYWRpdXM6OXB4OyBcclxufVxyXG5cclxuLm9ibGlnYWRve1xyXG5jb2xvcjogICNCQjIyMkU7XHJcbn1cclxuXHJcbi5hbGVydC1jaGVja2JveC1ncm91cDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gIHdpZHRoOiAxZW07XHJcbiAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmFsZXJ0LWNoZWNrYm94LWdyb3VwOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwwLDAsMC4zKTtcclxufVxyXG5cclxuLmFsZXJ0LWNoZWNrYm94LWdyb3VwOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogZGFya2dyZXk7XHJcbiAgb3V0bGluZTogMXB4IHNvbGlkIHNsYXRlZ3JleTtcclxufVxyXG5cclxuLmFjdGlvbi1zaGVldC1ncm91cCB7XHJcbiAgZmxleC1zaHJpbms6IDI7XHJcbiAgb3ZlcnNjcm9sbC1iZWhhdmlvci15OiBjb250YWluO1xyXG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcclxuICAtd2Via2l0LW92ZXJmbG93LXNjcm9sbGluZzogdG91Y2g7XHJcbiAgcG9pbnRlci1ldmVudHM6IGFsbDtcclxuXHJcbiAgYmFja2dyb3VuZDogdmFyKC0tYmFja2dyb3VuZCk7XHJcbn1cclxuIiwiLnRleHRvMSB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtZmFtaWx5OiBIZWx2ZXRpY2EgTmV1ZSBMVCBQcm87XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDA7XG4gIG9wYWNpdHk6IDE7XG4gIHBhZGRpbmctbGVmdDogMzBweDtcbiAgcGFkZGluZy1yaWdodDogMzBweDtcbn1cblxuLnRlbWExIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIG9wYWNpdHk6IDE7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1mYW1pbHk6IEhlbHZldGljYSBOZXVlIExUIFBybztcbiAgbGV0dGVyLXNwYWNpbmc6IDA7XG4gIGNvbG9yOiAjMzMzMzMzO1xuICBvcGFjaXR5OiAxO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG59XG5cbi50aXR1bG90YWJsYSB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtZmFtaWx5OiBIZWx2ZXRpY2EgTmV1ZSBMVCBQcm87XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxldHRlci1zcGFjaW5nOiAwO1xuICBjb2xvcjogIzI3MjcyNztcbiAgb3BhY2l0eTogMTtcbiAgcGFkZGluZy1ib3R0b206IDE1cHg7XG4gIHBhZGRpbmctdG9wOiAxNXB4O1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG59XG5cbi50ZXh0b1ByZWd1bnRhIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IEhlbHZldGljYSBOZXVlIExUIFBybztcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsZXR0ZXItc3BhY2luZzogMDtcbiAgY29sb3I6ICMyNzI3Mjc7XG4gIG9wYWNpdHk6IDE7XG4gIHBhZGRpbmctdG9wOiAyMHB4O1xuICBwYWRkaW5nLWJvdHRvbTogMjBweDtcbiAgcGFkZGluZy1sZWZ0OiAzMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xufVxuXG4uZmlsYSB7XG4gIGJvcmRlci1jb2xvcjogIzAwMDAwMDI5O1xuICBib3JkZXItd2lkdGg6IDFweDtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbn1cblxuLnRleHRvQm90b24ge1xuICBmb250OiBNZWRpdW0gMjVweC8zM3B4IFJvYm90bztcbiAgZm9udC1mYW1pbHk6IFJvYm90bztcbiAgbGV0dGVyLXNwYWNpbmc6IDA7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBvcGFjaXR5OiAxO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbn1cblxuLmFkdmVydGVuY2lhIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udDogUmVndWxhciAxMnB4LzE2cHggUm9ib3RvO1xuICBmb250LWZhbWlseTogUm9ib3RvO1xuICBmb250LXNpemU6IDEycHg7XG4gIGxldHRlci1zcGFjaW5nOiAwO1xuICBjb2xvcjogI2Y5NTQ1YjtcbiAgb3BhY2l0eTogMTtcbiAgcGFkZGluZy10b3A6IDIwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDMwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG59XG5cbi50ZXh0b2NlZHVsYSB7XG4gIGZvbnQtZmFtaWx5OiBSb2JvdG87XG4gIGZvbnQtc2l6ZTogMTFweDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tYm9yZGVyLXJhZGl1czo5cHg7XG59XG5cbi5vYmxpZ2FkbyB7XG4gIGNvbG9yOiAjQkIyMjJFO1xufVxuXG4uYWxlcnQtY2hlY2tib3gtZ3JvdXA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgd2lkdGg6IDFlbTtcbiAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbn1cblxuLmFsZXJ0LWNoZWNrYm94LWdyb3VwOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XG4gIC13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuMyk7XG59XG5cbi5hbGVydC1jaGVja2JveC1ncm91cDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBkYXJrZ3JleTtcbiAgb3V0bGluZTogMXB4IHNvbGlkIHNsYXRlZ3JleTtcbn1cblxuLmFjdGlvbi1zaGVldC1ncm91cCB7XG4gIGZsZXgtc2hyaW5rOiAyO1xuICBvdmVyc2Nyb2xsLWJlaGF2aW9yLXk6IGNvbnRhaW47XG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcbiAgLXdlYmtpdC1vdmVyZmxvdy1zY3JvbGxpbmc6IHRvdWNoO1xuICBwb2ludGVyLWV2ZW50czogYWxsO1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrZ3JvdW5kKTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/formulario/formulario.page.ts":
/*!***********************************************!*\
  !*** ./src/app/formulario/formulario.page.ts ***!
  \***********************************************/
/*! exports provided: FormularioPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormularioPage", function() { return FormularioPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _coneccion_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../coneccion.service */ "./src/app/coneccion.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm5/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _masinfo_masinfo_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../masinfo/masinfo.page */ "./src/app/masinfo/masinfo.page.ts");






var FormularioPage = /** @class */ (function () {
    function FormularioPage(alertController, cnx, platform, route, loadingController, modalController) {
        this.alertController = alertController;
        this.cnx = cnx;
        this.platform = platform;
        this.route = route;
        this.loadingController = loadingController;
        this.modalController = modalController;
        this.sp1 = false;
        this.sp2 = false;
        this.sp3 = false;
        this.vp1 = false;
        this.vp2 = false;
        this.vp3 = false;
        this.vp4 = false;
        this.vp5 = false;
        this.vp6 = false;
        this.vp7 = false;
        this.ot1 = false;
        this.ot2 = false;
        this.guardar = false;
        this.get();
    }
    FormularioPage.prototype.ngOnInit = function () {
        var _this = this;
        this.txtCedula = null;
        this.provincia_selecionado = null;
        this.canton_selecionado = null;
        this.parroquia_selecionado = null;
        this.cnx.getProvincia().subscribe(function (res) {
            _this.provincias = res.provincia;
            _this.provincia_selecionado = '18';
            _this.getcantones();
        }, function (error) {
            console.log(error);
        });
    };
    FormularioPage.prototype.ingresar = function () { };
    FormularioPage.prototype.getcantones = function () {
        var _this = this;
        this.canton_selecionado = null;
        this.cnx.getCanton().subscribe(function (data) {
            _this.cantones = data.canton.filter(function (item) { return item.dpa_provin == _this.provincia_selecionado; });
            _this.cantones.sort(function (a, b) {
                return a.dpa_descan < b.dpa_descan
                    ? -1
                    : a.dpa_descan > b.dpa_descan
                        ? 1
                        : 0;
            });
        });
        this.validarGuardar();
    };
    FormularioPage.prototype.getparroquias = function () {
        var _this = this;
        this.parroquia_selecionado = null;
        this.cnx.getParroquia().subscribe(function (data) {
            _this.parroquias = data.parroquia.filter(function (item) { return item.dpa_canton == _this.canton_selecionado; });
            _this.parroquias.sort(function (a, b) {
                return a.dpa_despar < b.dpa_despar
                    ? -1
                    : a.dpa_despar > b.dpa_despar
                        ? 1
                        : 0;
            });
        });
        this.validarGuardar();
    };
    FormularioPage.prototype.changeParroquias = function () {
        this.validarGuardar();
    };
    FormularioPage.prototype.validarGuardar = function () {
        this.guardar =
            this.provincia_selecionado !== null &&
                this.canton_selecionado !== null &&
                this.parroquia_selecionado !== null &&
                this.facultad !== null &&
                this.carrera !== null;
    };
    FormularioPage.prototype.guardarDatos = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading, vsp1, vsp2, vsp3, vvp1, vvp2, vvp3, vvp4, vvp5, vvp6, vvp7, vot1, vot2;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: "Guardando..."
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        vsp1 = this.sp1 ? 1 : 0;
                        vsp2 = this.sp2 ? 1 : 0;
                        vsp3 = this.sp3 ? 1 : 0;
                        vvp1 = this.vp1 ? 1 : 0;
                        vvp2 = this.vp2 ? 1 : 0;
                        vvp3 = this.vp3 ? 1 : 0;
                        vvp4 = this.vp4 ? 1 : 0;
                        vvp5 = this.vp5 ? 1 : 0;
                        vvp6 = this.vp6 ? 1 : 0;
                        vvp7 = this.vp7 ? 1 : 0;
                        vot1 = this.ot1 ? 1 : 0;
                        vot2 = this.ot2 ? 1 : 0;
                        if (this.platform.is("android")) {
                            this.dispositivo = "PC";
                        }
                        else if (this.platform.is("ios")) {
                            this.dispositivo = "IOS";
                        }
                        else {
                            this.dispositivo = "android";
                        }
                        this.cnx
                            .guardar(vsp1, vsp2, vsp3, vvp1, vvp2, vvp3, vvp4, vvp5, vvp6, vvp7, this.provincia_selecionado, this.canton_selecionado, this.parroquia_selecionado, this.dispositivo, this.txtCedula, this.lat, this.lon, vot1, vot2, this.facultad, this.carrera, this.txtCedula, this.txtLugartrabajo)
                            .subscribe(function (res) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, loading.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.alerta1();
                                        this.telemedicina();
                                        this.route.navigate(["/home"]);
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        this.limpiar();
                                        return [4 /*yield*/, loading.dismiss()];
                                    case 1:
                                        _a.sent();
                                        console.log(err);
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    FormularioPage.prototype.limpiar = function () {
        // this.guardar = false;
        this.txtCedula = null;
        this.sp1 = false;
        this.sp2 = false;
        this.sp3 = false;
        this.vp1 = false;
        this.vp2 = false;
        this.vp3 = false;
        this.vp4 = false;
        this.vp5 = false;
        this.vp6 = false;
        this.vp7 = false;
    };
    FormularioPage.prototype.alerta1 = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: "Gracias.",
                            message: "<strong>    Información enviada correctamente  </strong>",
                            buttons: ["Aceptar"]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    FormularioPage.prototype.get = function () {
        var _this = this;
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                if (position) {
                    _this.lat = position.coords.latitude;
                    _this.lon = position.coords.longitude;
                }
            });
        }
    };
    FormularioPage.prototype.presentModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _masinfo_masinfo_page__WEBPACK_IMPORTED_MODULE_5__["MasinfoPage"]
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    FormularioPage.prototype.reporte = function () {
        window.open('http://covid.uta.edu.ec/export.php');
    };
    FormularioPage.prototype.telemedicina = function () {
        if (this.sp1 || this.sp1 || this.sp3 || this.vp1 || this.vp2 || this.vp3 || this.vp4 || this.vp6 || this.vp7)
            window.open('https://cedia.zoom.us/my/covid19uta');
    };
    FormularioPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
        { type: _coneccion_service__WEBPACK_IMPORTED_MODULE_2__["ConeccionService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
    ]; };
    FormularioPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-formulario",
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./formulario.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/formulario/formulario.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./formulario.page.scss */ "./src/app/formulario/formulario.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _coneccion_service__WEBPACK_IMPORTED_MODULE_2__["ConeccionService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])
    ], FormularioPage);
    return FormularioPage;
}());



/***/ })

}]);
//# sourceMappingURL=formulario-formulario-module.js.map