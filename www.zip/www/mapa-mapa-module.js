(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mapa-mapa-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/mapa/mapa.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/mapa/mapa.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <table> \n    <tr> \n      \n        <td colspan=\"3\">          \n          <ion-select mode=\"ios\"\n          [(ngModel)]=\"indicador\"        \n          placeholder=\"Indicador\" \n          interface=\"alert\"\n        >\n          <ion-select-option value=\"sp1\"     >\n  \n            ¿Tiene fiebre, escalofríos o temblores?   \n         \n          </ion-select-option>\n\n          <ion-select-option value=\"sp2\" >\n            ¿Tiene una tos nueva o que empeora?\n          </ion-select-option>\n\n\n          <ion-select-option value=\"sp3\" >\n             ¿Experimenta dificultad para respirar? \n          </ion-select-option>\n\n          <ion-select-option value=\"vp1\" >\n            ¿Tiene 60 años de edad o más?\n          </ion-select-option>\n\n          <ion-select-option value=\"vp2\" >\n          ¿Tiene alguna de las siguientes condiciones médicas: diabetes, enfermedad cardíaca, cáncer activo, antecedentes de accidente cerebrovascular, asma, EPOC, diálisis o están inmunocomprometidos?\n          </ion-select-option>\n\n          <ion-select-option value=\"vp3\" >\n            ¿Ha viajado fuera de Ecuador en los últimos 14 días?\"\n          </ion-select-option>\n\n          <ion-select-option value=\"vp4\" >\n             ¿Has tenido contacto cercano con alguien que está tosiendo, tiene fiebre, o está enfermo y ha estado fuera de Ecuador en los últimos 14 días o ha sido diagnosticado con COVID-19?\n          </ion-select-option>\n\n        </ion-select>\n\n        </td>\n    </tr>\n    <tr>  \n      <td>   \n           <ion-select mode=\"ios\"\n        [(ngModel)]=\"provincia_selecionado\"\n        (ionChange)=\"getcantones( )\"\n        placeholder=\"Provincia\"\n      >\n        <ion-select-option\n          *ngFor=\"let provincia of provincias\"\n          value=\"{{provincia.dpa_provin}}\"\n        >\n          {{provincia.dpa_despro}}\n        </ion-select-option>\n      </ion-select>\n    \n    </td>\n      <td> \n        <ion-select mode=\"ios\"  [disabled]=\"!provincia_selecionado\"\n      \n        [(ngModel)]=\"canton_selecionado\"\n        (ionChange)=\"getparroquias( )\"\n        placeholder=\"Cantón\"\n      >\n        <ion-select-option \n          *ngFor=\"let canton of cantones\"\n          value=\"{{canton.dpa_canton}}\"\n        >\n          {{canton.dpa_descan}}\n        </ion-select-option>\n      </ion-select>\n\n      </td>\n  \n\n      <td>\n        <ion-button\n          [disabled]=\"!buscar\"\n          (click)=\"buscarDatos()\"\n        \n        >\n          <div class=\"textoBoton\">Buscar</div>\n        </ion-button>\n\n      </td>\n    </tr>\n  </table>\n</ion-header>\n\n<ion-content>\n \n  <div id=\"mapId\" style=\"width: 100%; height: 100%; \">\n  </div>\n \n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/mapa/mapa-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/mapa/mapa-routing.module.ts ***!
  \*********************************************/
/*! exports provided: MapaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapaPageRoutingModule", function() { return MapaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _mapa_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mapa.page */ "./src/app/mapa/mapa.page.ts");




var routes = [
    {
        path: '',
        component: _mapa_page__WEBPACK_IMPORTED_MODULE_3__["MapaPage"]
    }
];
var MapaPageRoutingModule = /** @class */ (function () {
    function MapaPageRoutingModule() {
    }
    MapaPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], MapaPageRoutingModule);
    return MapaPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/mapa/mapa.module.ts":
/*!*************************************!*\
  !*** ./src/app/mapa/mapa.module.ts ***!
  \*************************************/
/*! exports provided: MapaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapaPageModule", function() { return MapaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm5/ionic-angular.js");
/* harmony import */ var _mapa_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mapa-routing.module */ "./src/app/mapa/mapa-routing.module.ts");
/* harmony import */ var _mapa_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mapa.page */ "./src/app/mapa/mapa.page.ts");
/* harmony import */ var _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @asymmetrik/ngx-leaflet */ "./node_modules/@asymmetrik/ngx-leaflet/dist/index.js");








var MapaPageModule = /** @class */ (function () {
    function MapaPageModule() {
    }
    MapaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _mapa_routing_module__WEBPACK_IMPORTED_MODULE_5__["MapaPageRoutingModule"],
                _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_7__["LeafletModule"].forRoot()
            ],
            declarations: [_mapa_page__WEBPACK_IMPORTED_MODULE_6__["MapaPage"]]
        })
    ], MapaPageModule);
    return MapaPageModule;
}());



/***/ }),

/***/ "./src/app/mapa/mapa.page.scss":
/*!*************************************!*\
  !*** ./src/app/mapa/mapa.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21hcGEvbWFwYS5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/mapa/mapa.page.ts":
/*!***********************************!*\
  !*** ./src/app/mapa/mapa.page.ts ***!
  \***********************************/
/*! exports provided: MapaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapaPage", function() { return MapaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! leaflet */ "./node_modules/leaflet/dist/leaflet-src.js");
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(leaflet__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _coneccion_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../coneccion.service */ "./src/app/coneccion.service.ts");





var MapaPage = /** @class */ (function () {
    function MapaPage(cnx) {
        this.cnx = cnx;
    }
    MapaPage.prototype.ngOnInit = function () {
        var _this = this;
        this.get();
        this.provincia_selecionado = null;
        this.canton_selecionado = null;
        this.parroquia_selecionado = null;
        this.cnx.getProvincia().subscribe(function (res) {
            _this.provincias = res.provincia;
        }, function (error) {
            console.log(error);
        });
    };
    MapaPage.prototype.ionViewDidEnter = function () {
        this.leafletMap();
    };
    MapaPage.prototype.leafletMap = function () {
        // In setView add latLng and zoom
        this.map = new leaflet__WEBPACK_IMPORTED_MODULE_2__["Map"]("mapId").setView([-1.261491, -78.622951], 10);
        Object(leaflet__WEBPACK_IMPORTED_MODULE_2__["tileLayer"])("http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: "openstreetmap",
        }).addTo(this.map);
        /* marker([-1.261491, -78.622951])
          .addTo(this.map)
          .bindPopup("Ionic 4 <br> Leaflet.")
          .openPopup();
    */
        this.cargarMapa();
    };
    MapaPage.prototype.cargarMapa = function () {
        var _this = this;
        this.cnx.getgeojson().subscribe(function (data) {
            _this.geojson = leaflet__WEBPACK_IMPORTED_MODULE_2__["geoJSON"](data).addTo(_this.map);
            _this.initMapa(data);
        });
    };
    MapaPage.prototype.initMapa = function (data) {
        if (this.geojson != null) {
            this.geojson.remove();
        }
        if (this.legend != null) {
            this.legend.remove();
        }
        this.legend = leaflet__WEBPACK_IMPORTED_MODULE_2__["control"].scale({ position: "bottomright" });
        this.legend.onAdd = function (map) {
            var div = leaflet__WEBPACK_IMPORTED_MODULE_2__["DomUtil"].create("div", "info legend"), labels = [];
            var grades = [0, 1, 2, 3, 4];
            for (var i = 0; i < grades.length; i++) {
                var p = grades[i] + 1;
                var retorno = p > grades[7]
                    ? "#800026"
                    : p > grades[6]
                        ? "#BD0026"
                        : p > grades[5]
                            ? "#E31A1C"
                            : p > grades[4]
                                ? "#FC4E2A"
                                : p > grades[3]
                                    ? "#FD8D3C"
                                    : p > grades[2]
                                        ? "#FEB24C"
                                        : p > grades[1]
                                            ? "#FED976"
                                            : "#FFEDA0";
                div.innerHTML +=
                    '<div><i style="background-color:' + retorno + '"></i> ' +
                        grades[i] +
                        (grades[i + 1] ? "–" + grades[i + 1] : "+") +
                        "</div>";
            }
            return div;
        };
        this.legend.addTo(this.map);
        this.geojson = leaflet__WEBPACK_IMPORTED_MODULE_2__["geoJSON"](data, {
            style: this.style,
            onEachFeature: this.onEachFeature,
        }).addTo(this.map);
        this.map.fitBounds(this.geojson.getBounds());
    };
    MapaPage.prototype.ionViewWillLeave = function () {
        this.map.remove();
    };
    MapaPage.prototype.get = function () {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                if (position) {
                    var lat = position.coords.latitude;
                    var lng = position.coords.longitude;
                }
            });
        }
    };
    MapaPage.prototype.style = function (feature) {
        return {
            fillColor: feature.properties.sp1 == 0 ? "#E0E0E0" : "#FD2500",
            weight: 2,
            opacity: 0.3,
            color: "black",
            fillOpacity: 0.7,
            label: "dmeo",
        };
    };
    MapaPage.prototype.highlightFeature = function (e) {
        var layer = e.target;
        layer.setStyle({
            weight: 3,
            color: "#FF8",
            opacity: 1,
            dashArray: "",
            fillOpacity: 1,
        });
        layer.bringToFront();
        // this.info.update(layer.feature.properties);
    };
    MapaPage.prototype.resetHighlight = function (e) {
        this.geojson.resetStyle(e.target);
        //info.update();
    };
    MapaPage.prototype.zoomToFeature = function (e) {
        this.map.fitBounds(e.target.getBounds());
    };
    MapaPage.prototype.onEachFeature = function (feature, layer) {
        layer.on({
            mouseover: this.highlightFeature,
            mouseout: this.resetHighlight,
            click: this.zoomToFeature,
        });
    };
    MapaPage.prototype.getcantones = function () {
        var _this = this;
        this.canton_selecionado = null;
        this.cnx.getCanton().subscribe(function (data) {
            _this.cantones = data.canton.filter(function (item) { return item.dpa_provin == _this.provincia_selecionado; });
            _this.cantones.sort(function (a, b) {
                return a.dpa_descan < b.dpa_descan
                    ? -1
                    : a.dpa_descan > b.dpa_descan
                        ? 1
                        : 0;
            });
        });
        this.validarBuscar();
    };
    MapaPage.prototype.getparroquias = function () {
        var _this = this;
        this.parroquia_selecionado = null;
        this.cnx.getParroquia().subscribe(function (data) {
            _this.parroquias = data.parroquia.filter(function (item) { return item.dpa_canton == _this.canton_selecionado; });
            _this.parroquias.sort(function (a, b) {
                return a.dpa_despar < b.dpa_despar
                    ? -1
                    : a.dpa_despar > b.dpa_despar
                        ? 1
                        : 0;
            });
        });
        this.validarBuscar();
    };
    MapaPage.prototype.changeParroquias = function () {
        this.validarBuscar();
    };
    MapaPage.prototype.validarBuscar = function () {
        this.buscar =
            this.provincia_selecionado !== null && this.canton_selecionado !== null;
    };
    MapaPage.prototype.buscarDatos = function () {
        var _this = this;
        this.cnx
            .getParroquiasGeoJson(this.canton_selecionado, 0)
            .subscribe(function (data) {
            var datax = JSON.parse(data.preguntas_parroquias);
            _this.initMapa(datax);
        });
    };
    MapaPage.ctorParameters = function () { return [
        { type: _coneccion_service__WEBPACK_IMPORTED_MODULE_3__["ConeccionService"] }
    ]; };
    MapaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-mapa",
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./mapa.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/mapa/mapa.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./mapa.page.scss */ "./src/app/mapa/mapa.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_coneccion_service__WEBPACK_IMPORTED_MODULE_3__["ConeccionService"]])
    ], MapaPage);
    return MapaPage;
}());



/***/ })

}]);
//# sourceMappingURL=mapa-mapa-module.js.map