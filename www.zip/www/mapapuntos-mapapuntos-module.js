(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mapapuntos-mapapuntos-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/mapapuntos/mapapuntos.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/mapapuntos/mapapuntos.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n   \n</ion-header>\n\n<ion-content>\n\n  <table style=\"width: 100%; height: 100%; \" >\n    <tr height=\"90%\">\n      <td>   <div id=\"mapId\" style=\"width: 100%; height: 100%; \"></div>  </td>\n     \n    </tr>\n    <tr>\n      <td>     </td>\n     \n    </tr>\n\n  </table>\n\n   \n \n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/mapapuntos/mapapuntos-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/mapapuntos/mapapuntos-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: MapapuntosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapapuntosPageRoutingModule", function() { return MapapuntosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _mapapuntos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mapapuntos.page */ "./src/app/mapapuntos/mapapuntos.page.ts");




var routes = [
    {
        path: '',
        component: _mapapuntos_page__WEBPACK_IMPORTED_MODULE_3__["MapapuntosPage"]
    }
];
var MapapuntosPageRoutingModule = /** @class */ (function () {
    function MapapuntosPageRoutingModule() {
    }
    MapapuntosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], MapapuntosPageRoutingModule);
    return MapapuntosPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/mapapuntos/mapapuntos.module.ts":
/*!*************************************************!*\
  !*** ./src/app/mapapuntos/mapapuntos.module.ts ***!
  \*************************************************/
/*! exports provided: MapapuntosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapapuntosPageModule", function() { return MapapuntosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm5/ionic-angular.js");
/* harmony import */ var _mapapuntos_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mapapuntos-routing.module */ "./src/app/mapapuntos/mapapuntos-routing.module.ts");
/* harmony import */ var _mapapuntos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mapapuntos.page */ "./src/app/mapapuntos/mapapuntos.page.ts");







var MapapuntosPageModule = /** @class */ (function () {
    function MapapuntosPageModule() {
    }
    MapapuntosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _mapapuntos_routing_module__WEBPACK_IMPORTED_MODULE_5__["MapapuntosPageRoutingModule"]
            ],
            declarations: [_mapapuntos_page__WEBPACK_IMPORTED_MODULE_6__["MapapuntosPage"]]
        })
    ], MapapuntosPageModule);
    return MapapuntosPageModule;
}());



/***/ }),

/***/ "./src/app/mapapuntos/mapapuntos.page.scss":
/*!*************************************************!*\
  !*** ./src/app/mapapuntos/mapapuntos.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21hcGFwdW50b3MvbWFwYXB1bnRvcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/mapapuntos/mapapuntos.page.ts":
/*!***********************************************!*\
  !*** ./src/app/mapapuntos/mapapuntos.page.ts ***!
  \***********************************************/
/*! exports provided: MapapuntosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapapuntosPage", function() { return MapapuntosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! leaflet */ "./node_modules/leaflet/dist/leaflet-src.js");
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(leaflet__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _coneccion_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../coneccion.service */ "./src/app/coneccion.service.ts");





var MapapuntosPage = /** @class */ (function () {
    function MapapuntosPage(cnx) {
        this.cnx = cnx;
    }
    MapapuntosPage.prototype.ngOnInit = function () {
        this.get();
        this.provincia_selecionado = null;
        this.canton_selecionado = null;
        this.parroquia_selecionado = null;
    };
    MapapuntosPage.prototype.ionViewDidEnter = function () {
        this.leafletMap();
    };
    MapapuntosPage.prototype.leafletMap = function () {
        // In setView add latLng and zoom
        this.map = new leaflet__WEBPACK_IMPORTED_MODULE_2__["Map"]("mapId").setView([-1.261491, -78.622951], 10);
        Object(leaflet__WEBPACK_IMPORTED_MODULE_2__["tileLayer"])("http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: "openstreetmap",
        }).addTo(this.map);
        /* marker([-1.261491, -78.622951])
          .addTo(this.map)
          .bindPopup("Ionic 4 <br> Leaflet.")
          .openPopup();
    */
        this.cargarMapa();
    };
    MapapuntosPage.prototype.cargarMapa = function () {
        var _this = this;
        this.cnx.getPuntos().subscribe(function (data) {
            var datax = JSON.parse(data.fn_getpuntos);
            _this.geojson = leaflet__WEBPACK_IMPORTED_MODULE_2__["geoJSON"](datax).addTo(_this.map);
            _this.initMapa(datax);
        });
    };
    MapapuntosPage.prototype.initMapa = function (data) {
        if (this.geojson != null) {
            this.geojson.remove();
        }
        if (this.legend != null) {
            this.legend.remove();
        }
        this.geojson = leaflet__WEBPACK_IMPORTED_MODULE_2__["geoJSON"](data, {
            style: this.style,
            onEachFeature: this.onEachFeature,
        }).addTo(this.map);
        this.map.fitBounds(this.geojson.getBounds());
    };
    MapapuntosPage.prototype.ionViewWillLeave = function () {
        this.map.remove();
    };
    MapapuntosPage.prototype.get = function () {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                if (position) {
                    var lat = position.coords.latitude;
                    var lng = position.coords.longitude;
                }
            });
        }
    };
    MapapuntosPage.prototype.style = function (feature) {
        return {
            fillColor: feature.properties.sp1 == 0 ? "#E0E0E0" : "#FD2500",
            weight: 2,
            opacity: 0.3,
            color: "black",
            fillOpacity: 0.7,
            label: "dmeo",
        };
    };
    MapapuntosPage.prototype.highlightFeature = function (e) {
        var layer = e.target;
        layer.setStyle({
            weight: 3,
            color: "#FF8",
            opacity: 1,
            dashArray: "",
            fillOpacity: 1,
        });
        layer.bringToFront();
        // this.info.update(layer.feature.properties);
    };
    MapapuntosPage.prototype.resetHighlight = function (e) {
        this.geojson.resetStyle(e.target);
        //info.update();
    };
    MapapuntosPage.prototype.zoomToFeature = function (e) {
        this.map.fitBounds(e.target.getBounds());
    };
    MapapuntosPage.prototype.onEachFeature = function (feature, layer) {
        layer.on({
            mouseover: this.highlightFeature,
            mouseout: this.resetHighlight,
            click: this.zoomToFeature,
        });
    };
    MapapuntosPage.prototype.getcantones = function () {
        var _this = this;
        this.canton_selecionado = null;
        this.cnx.getCanton().subscribe(function (data) {
            _this.cantones = data.canton.filter(function (item) { return item.dpa_provin == _this.provincia_selecionado; });
            _this.cantones.sort(function (a, b) {
                return a.dpa_descan < b.dpa_descan
                    ? -1
                    : a.dpa_descan > b.dpa_descan
                        ? 1
                        : 0;
            });
        });
        this.validarBuscar();
    };
    MapapuntosPage.prototype.getparroquias = function () {
        var _this = this;
        this.parroquia_selecionado = null;
        this.cnx.getParroquia().subscribe(function (data) {
            _this.parroquias = data.parroquia.filter(function (item) { return item.dpa_canton == _this.canton_selecionado; });
            _this.parroquias.sort(function (a, b) {
                return a.dpa_despar < b.dpa_despar
                    ? -1
                    : a.dpa_despar > b.dpa_despar
                        ? 1
                        : 0;
            });
        });
        this.validarBuscar();
    };
    MapapuntosPage.prototype.changeParroquias = function () {
        this.validarBuscar();
    };
    MapapuntosPage.prototype.validarBuscar = function () {
        this.buscar =
            this.provincia_selecionado !== null && this.canton_selecionado !== null;
    };
    MapapuntosPage.prototype.buscarDatos = function () {
        var _this = this;
        this.cnx
            .getParroquiasGeoJson(this.canton_selecionado, 0)
            .subscribe(function (data) {
            var datax = JSON.parse(data.preguntas_parroquias);
            _this.initMapa(datax);
        });
    };
    MapapuntosPage.ctorParameters = function () { return [
        { type: _coneccion_service__WEBPACK_IMPORTED_MODULE_3__["ConeccionService"] }
    ]; };
    MapapuntosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-mapapuntos',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./mapapuntos.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/mapapuntos/mapapuntos.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./mapapuntos.page.scss */ "./src/app/mapapuntos/mapapuntos.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_coneccion_service__WEBPACK_IMPORTED_MODULE_3__["ConeccionService"]])
    ], MapapuntosPage);
    return MapapuntosPage;
}());



/***/ })

}]);
//# sourceMappingURL=mapapuntos-mapapuntos-module.js.map