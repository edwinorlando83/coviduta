(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (" \n\n<ion-content [fullscreen]=\"true\">\n  <ion-grid>\n\n    <ion-row  >\n      <ion-col\n      offset-xl=\"4\"\n      size-xl=\"4\"\n\n      offset-sm=\"2\"\n      size-sm=\"8\"\n\n      offset-md=\"3\"\n      size-md=\"6\"\n\n      offset-xs=\"1\"\n      size-xs=\"10\"\n      >\n       \n        <table style=\"width: 100%;\">\n          <tr>\n            <td align=\"center\" >\n              <img style=\"width: 100px;\" src=\"assets/logo2.jpg\"/> \n            </td>\n          </tr>\n\n          <tr> \n            <td align=\"center\">\n              <img style=\"margin-top: 50px;\" src=\"assets/COVIDUTA.svg\"/>\n            </td>\n          </tr>\n\n          <tr>\n            <td align=\"center\">\n              <div class=\"texto\">COVID UTA es una iniciativa para recolectar y proveer información acerca del esparcimiento del COVID-19 en tu comunidad universitaria.\n              </div>\n            </td>\n          </tr>\n\n\n          <tr>\n            <td style=\"padding: 30px;\"  align=\"center\">\n              <ion-button (click)=\"formulario()\"    class=\"textoBoton\" color=\"danger\"  >Ver encuesta</ion-button>\n            </td>\n          </tr>\n\n        </table>\n    \n        \n      \n    \n     \n       \n      </ion-col> \n   </ion-row>\n\n  \n\n  </ion-grid>\n\n\n  \n \n</ion-content>\n");

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm5/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                    }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-button {\n  --border-radius:9px;\n}\n\n.texto {\n  text-align: center;\n  font: Regular 19px/25px Roboto;\n  font-family: Helvetica Neue LT Pro;\n  font-size: 16px;\n  letter-spacing: 0;\n  color: #646464;\n  opacity: 1;\n  margin-top: 50px;\n}\n\n.textotitulo1 {\n  position: inline-block;\n  text-align: left;\n  font: Bold 60px/79px Roboto;\n  font-family: Roboto;\n  font-size: 60px;\n  letter-spacing: 0;\n  color: #212121;\n}\n\n.textotitulo2 {\n  position: inline-block;\n  text-align: left;\n  font: Regular 60px/79px Roboto;\n  font-family: Roboto;\n  font-size: 60px;\n  letter-spacing: 0;\n  color: #f9545b;\n}\n\n.tabla {\n  margin-top: 30px;\n  margin-left: 30px;\n  margin-bottom: 10px;\n}\n\n.textoBoton {\n  font-family: Helvetica Neue LT Pro;\n  font-size: 20px;\n  letter-spacing: 0;\n  color: #FFFFFF;\n  opacity: 1;\n  text-transform: none;\n  height: 50px;\n  margin-top: 100px;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9EOlxcT1JMQU5ET1xcVFJBQkFKT1NcXGNvdmlkMTlcXGNlcmNvL3NyY1xcYXBwXFxob21lXFxob21lLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxrQkFBQTtFQUNBLDhCQUFBO0VBRUEsa0NBQUE7RUFFQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0FDREY7O0FER0E7RUFDRSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUNBRjs7QURFQTtFQUNFLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUVBLGlCQUFBO0VBQ0EsY0FBQTtBQ0FGOztBREVBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FDQ0Y7O0FEQ0E7RUFFRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFFQSxXQUFBO0FDQUYiLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWJ1dHRvbntcbiAgLS1ib3JkZXItcmFkaXVzOjlweDsgXG59XG5cbi50ZXh0byB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udDogUmVndWxhciAxOXB4LzI1cHggUm9ib3RvO1xuIFxuICBmb250LWZhbWlseTogSGVsdmV0aWNhIE5ldWUgTFQgUHJvO1xuICBcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsZXR0ZXItc3BhY2luZzogMDtcbiAgY29sb3I6ICM2NDY0NjQ7XG4gIG9wYWNpdHk6IDE7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG59XG4udGV4dG90aXR1bG8xIHtcbiAgcG9zaXRpb246IGlubGluZS1ibG9jaztcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udDogQm9sZCA2MHB4Lzc5cHggUm9ib3RvO1xuICBmb250LWZhbWlseTogUm9ib3RvO1xuICBmb250LXNpemU6IDYwcHg7XG4gIGxldHRlci1zcGFjaW5nOiAwO1xuICBjb2xvcjogIzIxMjEyMTtcbn1cbi50ZXh0b3RpdHVsbzIge1xuICBwb3NpdGlvbjogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250OiBSZWd1bGFyIDYwcHgvNzlweCBSb2JvdG87XG4gIGZvbnQtZmFtaWx5OiBSb2JvdG87XG4gIGZvbnQtc2l6ZTogNjBweDtcblxuICBsZXR0ZXItc3BhY2luZzogMDtcbiAgY29sb3I6ICNmOTU0NWI7XG59XG4udGFibGEge1xuICBtYXJnaW4tdG9wOiAzMHB4O1xuICBtYXJnaW4tbGVmdDogMzBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cbi50ZXh0b0JvdG9uIHtcbiBcbiAgZm9udC1mYW1pbHk6IEhlbHZldGljYSBOZXVlIExUIFBybztcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsZXR0ZXItc3BhY2luZzogMDtcbiAgY29sb3I6ICNGRkZGRkY7XG4gIG9wYWNpdHk6IDE7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICBoZWlnaHQ6IDUwcHg7XG4gIG1hcmdpbi10b3A6IDEwMHB4O1xuICBcbiAgd2lkdGg6IDEwMCU7XG4gXG59XG4iLCJpb24tYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOjlweDtcbn1cblxuLnRleHRvIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250OiBSZWd1bGFyIDE5cHgvMjVweCBSb2JvdG87XG4gIGZvbnQtZmFtaWx5OiBIZWx2ZXRpY2EgTmV1ZSBMVCBQcm87XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDA7XG4gIGNvbG9yOiAjNjQ2NDY0O1xuICBvcGFjaXR5OiAxO1xuICBtYXJnaW4tdG9wOiA1MHB4O1xufVxuXG4udGV4dG90aXR1bG8xIHtcbiAgcG9zaXRpb246IGlubGluZS1ibG9jaztcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udDogQm9sZCA2MHB4Lzc5cHggUm9ib3RvO1xuICBmb250LWZhbWlseTogUm9ib3RvO1xuICBmb250LXNpemU6IDYwcHg7XG4gIGxldHRlci1zcGFjaW5nOiAwO1xuICBjb2xvcjogIzIxMjEyMTtcbn1cblxuLnRleHRvdGl0dWxvMiB7XG4gIHBvc2l0aW9uOiBpbmxpbmUtYmxvY2s7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQ6IFJlZ3VsYXIgNjBweC83OXB4IFJvYm90bztcbiAgZm9udC1mYW1pbHk6IFJvYm90bztcbiAgZm9udC1zaXplOiA2MHB4O1xuICBsZXR0ZXItc3BhY2luZzogMDtcbiAgY29sb3I6ICNmOTU0NWI7XG59XG5cbi50YWJsYSB7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG4gIG1hcmdpbi1sZWZ0OiAzMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuXG4udGV4dG9Cb3RvbiB7XG4gIGZvbnQtZmFtaWx5OiBIZWx2ZXRpY2EgTmV1ZSBMVCBQcm87XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDA7XG4gIGNvbG9yOiAjRkZGRkZGO1xuICBvcGFjaXR5OiAxO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgaGVpZ2h0OiA1MHB4O1xuICBtYXJnaW4tdG9wOiAxMDBweDtcbiAgd2lkdGg6IDEwMCU7XG59Il19 */");

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _coneccion_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../coneccion.service */ "./src/app/coneccion.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm5/ionic-angular.js");





var HomePage = /** @class */ (function () {
    function HomePage(route, cnx, alertController) {
        this.route = route;
        this.alertController = alertController;
    }
    HomePage.prototype.formulario = function () {
        if (sessionStorage.getItem("login") === null)
            this.administrar();
        else
            this.route.navigate(['/formulario']);
    };
    HomePage.prototype.administrar = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alerta;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Ingrese el Password!',
                            inputs: [
                                {
                                    name: 'password',
                                    type: 'password',
                                    placeholder: 'Password'
                                }
                            ],
                            buttons: [
                                {
                                    text: 'Cancel',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function () {
                                    }
                                }, {
                                    text: 'Ok',
                                    handler: function (txt) {
                                        if (txt.password === 'utaj01') {
                                            sessionStorage.setItem("login", "1");
                                            _this.route.navigate(['/formulario']);
                                        }
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alerta = _a.sent();
                        return [4 /*yield*/, alerta.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    HomePage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _coneccion_service__WEBPACK_IMPORTED_MODULE_3__["ConeccionService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
    ]; };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _coneccion_service__WEBPACK_IMPORTED_MODULE_3__["ConeccionService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], HomePage);
    return HomePage;
}());

//Clave12345!


/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map